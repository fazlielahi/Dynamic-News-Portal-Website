<?php

	// CONST DB_HOST = "localhost";
	// CONST DB_USERNAME = "root";
	// CONST DB_PASSWORD = "";
	 //CONST DB_DATABASE = "news-portal";
	
	$connection = mysqli_connect("localhost", "root", "");
	
	if(!$connection)
	{
		die("Error: Server not error ");
	}
	
	$database = mysqli_select_db($connection, "news-portal");
	
	if(!$database)
	{
		die("Error: Database not found");
	}
	
?>