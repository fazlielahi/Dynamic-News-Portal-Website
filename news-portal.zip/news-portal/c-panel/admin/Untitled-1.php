
<span class="field_heading"> Text </span>
				<textarea name='text' class="field textarea" name='text'> </textarea>
				<br /> <br />

				<div class="button">
					<a href="news.php" class="cancel_btn" onclick="hide_add_news()"> Cancel </a>
					<input type='submit' value='Save' class="save_btn"/>
				</div>